import { getAdminGroups, getAdminUsers } from "../api/adminApi"
import AdminGroupsSection from "../components/admin/AdminGroupSection";
import { useQuery } from "@tanstack/react-query";
import AdminUsersTable from "../components/admin/AdminUsersTable";
import AdminStats from "../components/admin/AdminStats";
import { getAdminStats } from "../api/adminApi";
const AdminPage = () => {

    const usersQuery = useQuery({
        queryKey: ["admin", "users"],
        queryFn: () => getAdminUsers()
    });

    const groupsQuery = useQuery({
        queryKey: ["admin", "groups"],
        queryFn: () => getAdminGroups()
    });
    const statsQuery = useQuery({
        queryKey: ["admin", "stats"],
        queryFn: getAdminStats
    });

    if (usersQuery.isPending || groupsQuery.isPending || statsQuery.isPending
    ) {
        return <p>טוען נתוני ניהול...</p>;
    }
    if (usersQuery.isError || groupsQuery.isError || statsQuery.isError
    ) {
        return <p>אירעה שגיאה בטעינת נתוני הניהול</p>;
    }

    return (

        <main className="admin-page">
            <h1>ניהול המערכת</h1>

            <AdminStats usersCount={statsQuery.data.usersCount} groupsCount={statsQuery.data.groupsCount} memoriesCount={statsQuery.data.memoriesCount} />

            <AdminUsersTable users={usersQuery.data.items} />

            <AdminGroupsSection groups={groupsQuery.data.items} />
        </main>
    );

};



export default AdminPage;

