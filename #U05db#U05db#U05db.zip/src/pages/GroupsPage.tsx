import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { getGroups } from "../api/groupsApi";
import GroupCard from "../components/GroupCard";
import GroupsFilters from "../pages/GroupsFilters";
import type { GroupFilters } from "../types/group.types";
import { Link } from "react-router";

const GroupsPage = () => {
    const [filters, setFilters] = useState<GroupFilters>({
        sort: "lastActivity",
        order: "desc",
        page: 1,
        limit: 12
    });

    const { data, isPending, isError, error } = useQuery({
        queryKey: ["groups", filters],
        queryFn: () => getGroups(filters),
    });
    console.log("Groups response:", data);
    return (
        <main>
            <h1>הקבוצות שלי</h1>
            <Link to="/groups/new" className="create--button">+ יצירת קבוצה חדשה</Link>
            <GroupsFilters filters={filters} onFiltersChange={setFilters} />
            {isPending ? (<p>אנחנו טוענים את הקבוצות שלך...</p>
            ) : isError ? (<p>שגיאה בטעינת הקבוצות: {error.message}</p>
            ) : data.items.length === 0 ? (<p>לא נמצאו קבוצות מתאימות</p>
            ) : (
                <div className="groups-grid">
                    {data.items.map((group) => (
                        <GroupCard key={group.id} group={group} />
                    ))}
                </div>
            )}
        </main>
    );
};

export default GroupsPage;
