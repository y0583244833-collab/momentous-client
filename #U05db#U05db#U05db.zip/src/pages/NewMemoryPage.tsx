import { useState } from "react";
import { useParams } from "react-router";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { memorySchema, memoryTypes, type MemoryFormData } from "../validation/memorySchemas";
import { createMemory } from "../api/memoriesApi";
import { uploadImage } from "../api/imageApi";
import type { CreateMemoryRequest, MemoryType } from "../types/memory.types";
import "./p.css"

interface NewMemoryPageProps {
    onClose: () => void;
}

const NewMemoryPage = ({ onClose }: NewMemoryPageProps) => {
    const { groupId } = useParams();
    const queryClient = useQueryClient();
    const [image, setImage] = useState<File | null>(null);
    const [imageError, setImageError] = useState("");
    const {
        register,
        handleSubmit,
        watch,
        setValue,
        formState: { errors }
    } = useForm<MemoryFormData>({
        resolver: yupResolver(memorySchema),
        defaultValues: {
            type: "PHOTO",
            title: "תמונה",
            content: "",
            placeUrl: "",
            happenedAt: ""
        }
    });
    const type = watch("type");
    const mutation = useMutation({
        mutationFn: async (data: MemoryFormData) => {
            if (!groupId) throw new Error("לא נמצאה קבוצה");
            let imageId: string | undefined;
            if (data.type === "PHOTO" && image) {
                const result = await uploadImage(image);
                imageId = result.id;
            }
            const request: CreateMemoryRequest = {
                type: data.type,
                title: data.title.trim(),
                content: data.content.trim(),
                ...(imageId && { imageId }),
                ...(data.type === "PLACE" && data.placeUrl && {
                    placeUrl: data.placeUrl.trim()
                }),
                ...(data.happenedAt && { happenedAt: data.happenedAt })
            };

            return createMemory(groupId, request);
        },

        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ["memories", groupId] });
            queryClient.invalidateQueries({ queryKey: ["group", groupId] });
            onClose();
        }
    });

    const onSubmit = (data: MemoryFormData) => {
        setImageError("");

        if (data.type === "PHOTO" && !image) {
            setImageError("חובה לבחור תמונה");
            return;
        }
        mutation.mutate(data);
    };

    return (
        <main>
            <h1>הוספת זיכרון</h1>
            <form onSubmit={handleSubmit(onSubmit)}>
                <div>
                    <label>מה תרצו להוסיף?</label>
                    <select
                        {...register("type", {
                            onChange: event => {
                                const selected = event.target.value as MemoryType;
                                const label = memoryTypes.find(item => item.value === selected)?.label ?? "זיכרון";
                                setValue("title", selected === "PHOTO" || selected === "QUOTE" ? label : "");
                                setValue("content", "");
                                setValue("placeUrl", "");
                                setValue("happenedAt", "");
                                setImage(null);
                                setImageError("");
                            }
                        })}>
                        {memoryTypes.map(item => (<option key={item.value} value={item.value}> {item.label}</option>))}
                    </select>
                </div>
                {type !== "PHOTO" && type !== "QUOTE" && (
                    <div>
                        <label>{type === "PLACE" ? "שם המקום" : "כותרת"} </label>
                        <input {...register("title")} />
                        <p>{errors.title?.message}</p>
                    </div>
                )}
                <div>
                    <label>
                        {type === "PHOTO" ? "תיאור התמונה" : type === "QUOTE" ? "הציטוט" :
                            type === "PLACE" ? "תיאור המקום" : type === "JOKE" ? "מה היה מצחיק?" : "סיכום החוויה"}
                    </label>
                    <textarea rows={4} {...register("content")} />
                    <p>{errors.content?.message}</p>
                </div>

                {type === "PHOTO" && (<div> <label>העלאת תמונה</label>
                    <input
                        type="file" accept="image/*"
                        onChange={event => {
                            setImage(event.target.files?.[0] ?? null);
                            setImageError("");
                        }}
                    />
                    <p>{imageError}</p>
                </div>
                )}

                {type === "PLACE" && (
                    <div>
                        <label>קישור למיקום (לא חובה)</label>
                        <input type="url"
                            {...register("placeUrl")}
                            placeholder="https://..." />
                        <p>{errors.placeUrl?.message}</p>
                    </div>
                )}
                {(type === "PHOTO" || type === "PLACE" || type === "SUMMARY") && (
                    <div>
                        <label>תאריך הזיכרון (לא חובה)</label>
                        <input type="date" {...register("happenedAt")} />
                    </div>
                )}
                {mutation.isError && (<p role="alert">אירעה שגיאה בשמירת הזיכרון </p>)}
                <button type="submit" disabled={mutation.isPending}>{mutation.isPending ? "שומר..." : "שמירת זיכרון"}</button>
                <button type="button" onClick={onClose} > ביטול </button>
            </form>
        </main>
    );
};

export default NewMemoryPage;
