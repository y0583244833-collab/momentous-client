import { Link, useParams } from "react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { getGroupById } from "../api/groupsApi";
import type { Group } from "../types/group.types";
import GroupInfo from "../components/GroupInfo";
import NewMemoryPage from "./NewMemoryPage";
import MemoriesSection from "../components/MemoriesSection";
import InviteMembersForm from "../components/InviteMembersForm";
import GroupMembersHover from "../components/GroupMembersHover";
const formatDate = (date: string) => {
    const parsed = new Date(date);

    if (Number.isNaN(parsed.getTime())) {
        return "תאריך לא זמין";
    }

    return parsed.toLocaleDateString("he-IL", {
        day: "numeric",
        month: "long",
        year: "numeric"
    });
};

const GroupDetailsPage = () => {
    const { groupId } = useParams<{ groupId: string }>();
    const [showMemoryModal, setShowMemoryModal] = useState(false);
    const [showInviteModal, setShowInviteModal] = useState(false);

    const {
        data: group,
        isPending,
        isError
    } = useQuery<Group>({
        queryKey: ["group", groupId],
        queryFn: () => getGroupById(groupId!),
        enabled: Boolean(groupId)
    });

    if (!groupId) {
        return (
            <main className="group-details-page" dir="rtl">
                <p>מזהה הקבוצה חסר.</p>
                <Link to="/groups">חזרה לקבוצות</Link>
            </main>
        );
    }
    if (isPending) {
        return (
            <main className="group-details-page" dir="rtl">
                <p role="status">טוענים את פרטי הקבוצה...</p>
            </main>
        );
    }
    if (isError || !group) {
        return (
            <main className="group-details-page" dir="rtl">
                <h1>לא הצלחנו לטעון את הקבוצה</h1>
                <p>
                    ייתכן שהקבוצה אינה קיימת או שאין לך הרשאה לצפות בה.
                </p>
                <Link to="/groups">חזרה לקבוצות</Link>
            </main>
        );
    }

    return (
        <main className="group-details-page" dir="rtl">

            <nav className="group-details-navigation">
                <Link to="/groups"> ← חזרה לכל הקבוצות </Link>
            </nav>
            <section className="group-details-hero">
                {group.coverImageUrl ? (
                    <img
                        src={group.coverImageUrl}
                        alt={`תמונת הכיסוי של ${group.name}`}
                        className="group-details-cover"
                    />
                ) : (
                    <div className="group-details-placeholder">
                        <span aria-hidden="true">📷</span>
                        <p>עדיין לא נוספה תמונת כיסוי</p>
                    </div>
                )}

                <div className="group-details-heading">
                    <span className="group-details-type">
                        {group.eventTypeLabel}
                    </span>

                    <h1>{group.name}</h1>
                    <p> תאריך האירוע: {formatDate(group.eventDate)}</p>
                </div>
            </section>
            <GroupInfo group={group} />
            <section className="group-details-section">
                <div className="group-details-section-header">
                    <div>
                        <h2>הזיכרונות שלנו</h2>
                        <p>{group.memoriesCount} זיכרונות בקבוצה</p>
                    </div>

                    <button
                        type="button"
                        onClick={() => setShowMemoryModal(true)}
                    > + הוספת זיכרון </button>
                </div>

                <MemoriesSection groupId={groupId} />
            </section>

            <section className="group-details-section">
                <h2>ניהול הקבוצה</h2>

                <div className="group-details-actions">
                    {group.isCreator && (
                        <button
                            type="button"
                            onClick={() => setShowInviteModal(true)}
                        >
                            + הזמנת משתתפים
                        </button>
                    )}
                    <GroupMembersHover groupId={group.id} />

                    {group.isCreator && (<Link to={`/groups/${group.id}/edit`}> עריכת פרטי הקבוצה </Link>)}
                </div>
            </section>
            {showMemoryModal && (
                <div className="memory-modal-overlay">
                    <div
                        className="memory-modal-content"
                        role="dialog"
                        aria-modal="true"
                        aria-label="הוספת זיכרון"
                    >
                        <NewMemoryPage onClose={() => setShowMemoryModal(false)} />
                    </div>
                </div>
            )}
            {group.isCreator && showInviteModal && (
                <div className="memory-modal-overlay">
                    <div
                        className="memory-modal-content"
                        role="dialog"
                        aria-modal="true"
                        aria-label="הזמנת משתתפים"
                    >
                        <button
                            type="button"
                            onClick={() => setShowInviteModal(false)}
                        >
                            ✕ סגירה
                        </button>

                        <InviteMembersForm groupId={groupId} />
                    </div>
                </div>
            )}
        </main>
    );
};

export default GroupDetailsPage;
