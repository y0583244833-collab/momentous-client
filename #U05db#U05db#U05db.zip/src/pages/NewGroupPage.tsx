import { useEffect, useState } from "react";
import { useForm, useWatch } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { useNavigate } from "react-router";
import { useQueryClient } from "@tanstack/react-query";
import axios from "axios";

import { groupSchema, type GroupFormValues } from "../validation/schemas";
import { createGroup } from "../api/groupsApi";
import { uploadImage } from "../api/imageApi";

const NewGroupPage = () => {
        const navigate = useNavigate();
        const queryClient = useQueryClient();

        const [emailInput, setEmailInput] = useState("");
        const [emailError, setEmailError] = useState("");
        const [submitError, setSubmitError] = useState("");
        const [imagePreview, setImagePreview] = useState<string | null>(null);

        const {
                register,
                control,
                setValue,
                getValues,
                handleSubmit,
                formState: { errors, isSubmitting }
        } = useForm<GroupFormValues>({
                resolver: yupResolver(groupSchema),
                mode: "onBlur",
                defaultValues: {
                        name: "",
                        description: "",
                        eventType: "TRIP",
                        eventDate: "",
                        emails: [],
                        coverImage: null
                }
        });

        const emails = useWatch({control, name: "emails"}) ?? [];
        const coverImage = useWatch({control, name: "coverImage" });
        useEffect(() => {
                if (!coverImage) {
                        setImagePreview(null);
                        return;
                }
                const url = URL.createObjectURL(coverImage);
                setImagePreview(url);
                return () => URL.revokeObjectURL(url);
        }, [coverImage]);
        const addEmail =  () => {
                const email = emailInput.trim().toLowerCase();
                setEmailError("");
                if (!email) {
                        setEmailError("יש להזין כתובת אימייל");
                        return;
                }
                if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                        setEmailError("כתובת אימייל לא תקינה");
                        return;
                }
                if (email.length > 254) {
                        setEmailError("כתובת האימייל ארוכה מדי");
                        return;
                }
                const currentEmails = getValues("emails");
                if (currentEmails.includes(email)) {
                        setEmailError("האימייל כבר נמצא ברשימה");
                        return;
                }
                if (currentEmails.length >= 20) {
                        setEmailError("אפשר להזמין עד 20 משתתפים");
                        return;
                }
                setValue(
                        "emails",
                        [...currentEmails, email],
                        { shouldValidate: true, shouldDirty: true }
                );

                setEmailInput("");

        };
        const removeEmail = (email: string) => {
                setValue("emails",
                        getValues("emails").filter(item => item !== email),
                        { shouldValidate: true, shouldDirty: true }
                );

                setEmailError("");
        };

       const onSubmit = async (data: GroupFormValues) => {
                      setSubmitError("");

    try {
        let coverImageId: string | undefined;

        if (data.coverImage) {
            const uploadedImage = await uploadImage(data.coverImage);
            coverImageId = uploadedImage.id;
        }
        const newGroup = await createGroup({
            name: data.name,
            description: data.description || undefined,
            eventType: data.eventType,
            eventDate: data.eventDate,
            coverImageId,
            emails: data.emails
        });
        await queryClient.invalidateQueries({
            queryKey: ["groups"]
        });
        navigate(`/groups/${newGroup.id}`);

    } catch (error) {
        if (axios.isAxiosError(error)) {
            setSubmitError(
                error.response?.data?.error?.message ??
                error.response?.data?.message ??
                "אירעה שגיאה ביצירת הקבוצה"
            );
        } else {
            setSubmitError("אירעה שגיאה בלתי צפויה");
        }
    }
};
        return (
                <main className="new-group-page" dir="rtl">
                        <header>
                                <h1>יצירת קבוצה חדשה</h1>
                                <p> צרי מקום משותף לתמונות ולזיכרונות שלכם</p>
                        </header>
                        <form onSubmit={handleSubmit(onSubmit)}>
                                    <section>
                                       <h2>פרטי הקבוצה</h2>
                                        <div>
                                                <label htmlFor="name"> שם הקבוצה *</label>
                                                <input
                                                        id="name"  type="text"
                                                        placeholder="לדוגמה: הטיול השנתי שלנו"
                                                        {...register("name")}
                                                />
                                                {errors.name && (<p role="alert">{errors.name.message}</p> )}
                                        </div>
                                        <div>
                                               <label htmlFor="description">תיאור הקבוצה</label>
                                                <textarea
                                                        id="description"  rows={4}  placeholder="ספרי קצת על הקבוצה..."
                                                        {...register("description")}
                                                />
                                                {errors.description && ( <p role="alert"> {errors.description.message}</p> )}
                                        </div>
                                        <div>
                                                <label htmlFor="eventType"> סוג האירוע *</label>
                                                <select
                                                        id="eventType" {...register("eventType")}>
                                                        <option value="TRIP">טיול</option>
                                                        <option value="GRADUATION">סיום לימודים</option>
                                                        <option value="CAMP">מחנה</option>
                                                        <option value="FAMILY">משפחה</option>
                                                        <option value="OTHER">אחר</option>
                                                </select>
                                                {errors.eventType && (<p role="alert">{errors.eventType.message} </p>)}
                                        </div>
                                        <div>
                                                <label htmlFor="eventDate">תאריך האירוע *</label>
                                                <input
                                                        id="eventDate"       type="date"
                                                        {...register("eventDate")} />
                                                {errors.eventDate && (<p role="alert">{errors.eventDate.message}</p>)}
                                        </div>
                                </section>
                                <section>
                                        <h2>תמונת כיסוי</h2>
                                        <label htmlFor="coverImage"> בחרי תמונה לקבוצה </label>
                                        <input
                                                id="coverImage"
                                                type="file"
                                                accept="image/jpeg,image/png,image/webp"
                                                onChange={(event) => {
                                                        const file = event.target.files?.[0] ?? null;
                                                        setValue("coverImage", file, {
                                                                shouldValidate: true,
                                                                shouldDirty: true
                                                        });
                                                }}
                                        />

                                        {errors.coverImage && (<p role="alert">{errors.coverImage.message} </p> )}
                                        {imagePreview && (<div>
                                                       <img
                                                                src={imagePreview}
                                                                alt="תצוגה מקדימה של תמונת הכיסוי"
                                                                style={{
                                                                        maxWidth: "300px",
                                                                        width: "100%",
                                                                        borderRadius: "12px"
                                                                }}
                                                        />
                                                        <button
                                                                type="button"
                                                                onClick={() =>
                                                                        setValue("coverImage", null, {
                                                                                shouldValidate: true,
                                                                                shouldDirty: true
                                                                        })
                                                                } > הסרת התמונה
                                                        </button>
                                                </div>
                                        )}
                                </section>

                                {/* הזמנת משתתפים */}
                                <section>
                                        <h2>הזמנת משתתפים</h2>

                                        <p>
                                                אפשר להזמין גם משתמשים שכבר רשומים
                                                וגם משתמשים שעדיין לא נרשמו.
                                        </p>

                                        <label htmlFor="inviteEmail"> כתובת אימייל
                                        </label>
                                        <div>
                                                <input
                                                        id="inviteEmail"
                                                        type="email"
                                                        value={emailInput}
                                                        placeholder="example@gmail.com"
                                                        onChange={(event) => {
                                                                setEmailInput(event.target.value);
                                                                setEmailError("");
                                                        }}
                                                        onKeyDown={(event) => {
                                                                if (event.key === "Enter") {
                                                                        event.preventDefault();
                                                                        void addEmail();
                                                                }
                                                        }}
                                                />

                                                <button
                                                        type="button"
                                                        onClick={() => void addEmail()}
                                                >
                                                        הוספת משתתף
                                                </button>
                                        </div>

                                        {emailError && (
                                                <p role="alert">{emailError}</p>
                                        )}

                                        {errors.emails && (
                                                <p role="alert">
                                                        {errors.emails.message}
                                                </p>
                                        )}

                                        <p>משתתפים להזמנה: {emails.length}/20</p>

                                        <ul>
                                                {emails.map(email => (
                                                        <li key={email}>
                                                                <span>{email}</span>

                                                                <button
                                                                        type="button"
                                                                        onClick={() => removeEmail(email)}
                                                                        aria-label={`הסרת ${email}`}
                                                                >
                                                                        הסרה
                                                                </button>
                                                        </li>
                                                ))}
                                        </ul>
                                </section>

                                {/* הודעות וכפתורים */}
                                {submitError && (
                                        <p role="alert">{submitError}</p>
                                )}

                                <div>
                                        <button
                                                type="button"
                                                onClick={() => navigate("/groups")}
                                                disabled={isSubmitting}
                                        >
                                                ביטול
                                        </button>

                                        <button
                                                type="submit"
                                                disabled={isSubmitting}
                                        >
                                                {isSubmitting
                                                        ? "יוצרים קבוצה..."
                                                        : "יצירת קבוצה"}
                                        </button>
                                </div>

                        </form>
                </main>
        );
};

export default NewGroupPage;