import type { GroupFilters, EventType } from "../types/group.types";

interface GroupsFiltersProps {
    filters: GroupFilters;
    onFiltersChange: (filters: GroupFilters) => void;
}

const GroupsFilters = ({filters,onFiltersChange}: GroupsFiltersProps) => {
    return (
        <div className="groups-filters">
            <input
                type="search" placeholder="חיפוש קבוצה..." value={filters.q ?? ""}
                onChange={(e) =>
                    onFiltersChange({...filters, q: e.target.value, page: 1})
                }
            />
            <select
                value={filters.role ?? "all"}
                onChange={(e) =>
                    onFiltersChange({...filters,
                        role: e.target.value === "all"? undefined: e.target.value as GroupFilters["role"],
                        page: 1
                    })
                }
            >
                <option value="all">כל הקבוצות</option>
                <option value="created">קבוצות שיצרתי</option>
                <option value="joined">קבוצות שהצטרפתי</option>
            </select>

            <select
                value={filters.eventType ?? "all"}
                onChange={(e) =>
                    onFiltersChange({...filters,eventType: e.target.value === "all"
                            ? undefined: e.target.value as EventType, page: 1
                    })
                } >
                <option value="all">כל סוגי האירועים</option>
                <option value="TRIP">טיול</option>
                <option value="GRADUATION">סיום לימודים</option>
                <option value="CAMP">מחנה</option>
                <option value="FAMILY">משפחה</option>
                <option value="OTHER">אחר</option>
            </select>

            <select
                value={filters.sort ?? "lastActivity"}
                onChange={(e) => {
                    const sort = e.target.value as GroupFilters["sort"];

                    onFiltersChange({...filters,sort, order: sort === "name" ? "asc" : "desc",page: 1
                    });
                }} 
                
                >
                <option value="lastActivity">פעילות אחרונה</option>
                <option value="eventDate">תאריך האירוע</option>
                <option value="name">שם הקבוצה</option>
            </select>

        </div>
    );
};
export default GroupsFilters;
