import { NavLink } from "react-router"

const NotFoundPage=()=>{
return(
    <>
    <h1>404</h1>
    <p>שגיאה 404 עמוד לא נמצא</p>
    <NavLink to="/">חזרה לדף הבית</NavLink>
    </>
)
}
export default NotFoundPage;