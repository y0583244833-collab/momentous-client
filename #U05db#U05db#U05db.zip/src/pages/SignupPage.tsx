import { yupResolver } from "@hookform/resolvers/yup";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router";
import type { SignUpRequest} from "../types/auth.types";
import axios from "axios";
import { useContext, useEffect, useState } from "react";
import { AuthContext } from "../context/AuthContext";
import { signupSchema } from "../validation/schemas";
import { registerUser, uploadProfileImage, updateProfileImage } from "../api/authApi";
const SignUpPage = () => {
        const navigate = useNavigate();
        const [signupError, setSignUpError] = useState<string>("");
        const [imageError, setImageError] = useState<string>("");
        const [registrationCompleted, setRegistrationCompleted] = useState(false);
        const [selectedFile, setSelectedFile] = useState<File | null>(null);
        const [imagePreview, setImagePreview] = useState<string | null>(null);
        const auth = useContext(AuthContext);
        useEffect(() => {
                if (!selectedFile) {
                        setImagePreview(null);
                        return;
                }

                const url = URL.createObjectURL(selectedFile);
                setImagePreview(url);

                return () => URL.revokeObjectURL(url);
        }, [selectedFile]);
        const onSubmit = async (data: SignUpRequest) => {
                if (registrationCompleted) return;
                setImageError("");
                setSignUpError("");
                try {
                        const result = await registerUser(data);
                        auth?.login(result);
                        setRegistrationCompleted(true);
                        if (selectedFile) {
                                try {
                                        const image = await uploadProfileImage(selectedFile, result.token);
                                        const user = await updateProfileImage(image.id, result.token);
                                        auth?.updateUser(user);
                                } catch {
                                        setImageError("ההרשמה הצליחה, אבל העלאת התמונה נכשלה");
                                        return;
                                }
                        }
                        navigate("/groups", { replace: true });
                } catch (error) {
                        if (axios.isAxiosError(error)) {
                                setSignUpError(error.response?.data?.message ?? "לא ניתן להתחבר לשרת");
                        } else {
                                setSignUpError("אירעה שגיאה לא צפויה. נסי שוב.");
                        }
                }
        };
        const {
                register,
                handleSubmit,
                formState: { errors, isSubmitting }
        } = useForm<SignUpRequest>({
                resolver: yupResolver(signupSchema),
                mode: "onBlur",
                reValidateMode: "onChange"
        });
        return (
                <form onSubmit={handleSubmit(onSubmit)}>
                      <h1>הרשמה</h1>
                        <label htmlFor="fullName">שם מלא</label>
                        <input type="text"  id="fullName" {...register("fullName")} />
                        <p>{errors.fullName?.message}</p>
                        <label htmlFor="email">מייל</label>
                        <input type="email" id="email" {...register("email")}/>
                        <p>{errors.email?.message}</p>
                        <label htmlFor="password">סיסמא</label>
                        <input type="password" id="password" {...register("password")} />
                        <p>{errors.password?.message}</p>
                        <div style={{display: "flex",flexDirection: "column", alignItems: "center",  gap: "12px",margin: "20px 0" }}>
                                <img
                                        src={imagePreview || "/default-avatar.svg"}
                                        alt="תמונת פרופיל"
                                        style={{
                                                width: "90px",
                                                height: "90px",
                                                borderRadius: "50%",
                                                objectFit: "cover",
                                                border: "2px solid #ddd"
                                        }}
                                />

                                <label htmlFor="avatar">תמונת פרופיל (לא חובה) </label>
                                <input type="file" id="avatar" accept="image/jpeg,image/png,image/webp" 
                                onChange={(e) => {
                                                const file = e.target.files?.[0];
                                                if (!file) return;
                                                if (file.size > 2 * 1024 * 1024) {
                                                        setImageError("התמונה גדולה מדי. ניתן להעלות עד 2MB");
                                                        e.target.value = "";
                                                        return
                                                }
                                                if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
                                                        setImageError("ניתן להעלות רק תמונות JPG, PNG או WebP");
                                                        e.target.value = "";
                                                        return;
                                                }

                                                setImageError("");
                                                setSelectedFile(file);

                                        }}
                                />

                                {selectedFile && (
                                        <button type="button"
                                                onClick={() => {
                                                        setSelectedFile(null);
                                                        setImageError("");
                                                }}
                                        >
                                                הסרת תמונה
                                        </button>
                                )}
                                {imageError && !registrationCompleted && (
                                        <p role="alert" style={{ color: "red" }}>{imageError} </p>  )}
                       </div>
                        {!registrationCompleted && (
                                <button type="submit"   disabled={isSubmitting} >
                                        {isSubmitting ? "נרשם..." : "הרשמה"}
                                </button>
                        )}
                        {signupError && (<p role="alert">{signupError}</p>)}
                        {imageError && (<button
                                type="button"
                                onClick={() =>
                                        navigate("/groups", { replace: true })
                                } > המשך ללא תמונה
                        </button>  )}
                </form>
        );
};
export default SignUpPage;
