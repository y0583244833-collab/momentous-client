import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router";
import type { LoginRequest } from "../types/auth.types";
import { useState } from "react";
import axios from "axios";
import { useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import { loginUser } from "../api/authApi";
import { loginSchema } from "../validation/schemas";

const LoginPage = () => {
    const navigate = useNavigate();
    const [loginError, setLoginError] = useState<string>("");
    const auth = useContext(AuthContext);
    const {
        register,
        handleSubmit,
        formState: { errors, isSubmitting }
    } = useForm<LoginRequest>({
        resolver: yupResolver(loginSchema), mode: "onBlur",
        reValidateMode: "onChange"
    })
    const onSubmit = async (data: LoginRequest) => {
        setLoginError("");
        try {
            const result = await loginUser(data);
            auth?.login(result);
            if (result.user.role === "ADMIN") {
                navigate("/admin", { replace: true });
            } else {
                navigate("/groups", { replace: true });
            }
        }
        catch (error) {
            if (axios.isAxiosError(error)) {
                setLoginError(error.response?.data?.message ?? "לא ניתן להתחבר לשרת")
            }
            else {
                setLoginError("אירעה שגיאה לא צפויה");
            }
        }
    }
    return (
        <form onSubmit={handleSubmit(onSubmit)}>
            <h1>התחברות</h1>
            <label htmlFor="email">מייל</label>
            <input type="email"
                id="email"
                {...register("email"
                )} />

            <p>{errors.email?.message}</p>
            <label htmlFor="password">סיסמא</label>
            <input type="password"
                id="password"
                {...register("password")}
            />
            <p>{errors.password?.message}</p>
            <button type="submit" disabled={isSubmitting} >{isSubmitting ? "מתחבר..." : "התחברות"}</button>
            {loginError && <p role="alert">{loginError}</p>}
        </form  >
    )
};
export default LoginPage;