import type { Invitation } from "../types/invitation.types";
interface Props {
    invitation: Invitation;
    onAccept: (id: string) => void;
    onDecline: (id: string) => void;
    disabled: boolean;
}

const InvitationCard = ({ invitation, onAccept, onDecline, disabled }: Props) => (
    <article className="bell-invitation">
        <strong>{invitation.board.name}</strong>
        <p>{invitation.inviter.fullName} הזמין אותך להצטרף</p>

        <div className="bell-actions">
            <button
                type="button"
                disabled={disabled}
                onClick={() => onAccept(invitation.id)}
            > ✓ אישור   </button>
            <button
                type="button"
                disabled={disabled}
                onClick={() => onDecline(invitation.id)}
            > דחייה  </button>
        </div>
    </article>
);

export default InvitationCard;