import type { AdminUser } from "../../types/admin.types";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { setUserBlocked } from "../../api/adminApi";
import { useState } from "react";
type Props = {
    users: AdminUser[];
};

const AdminUsersTable = ({ users }: Props) => {
    const queryClient = useQueryClient();
    const [actionError, setActionError] = useState("");

    const blockMutation = useMutation({
        mutationFn: ({ userId, isBlocked }
            : { userId: string, isBlocked: boolean }) => setUserBlocked(userId, isBlocked),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ["admin", "users"] });
        },
        onError: () => {
            setActionError("לא ניתן לעדכן את מצב המשתמש");
        }
    });
       const regularUsers = users.filter(user => user.role === "USER");
    return (
        <section className="admin-users">
            <h2>ניהול משתמשים</h2>
            {actionError && (<p role="alert">{actionError}</p>)}
            <table>
                <thead>
                    <tr>
                        <th>משתמש</th>
                        <th>קבוצות שיצר</th>
                        <th>קבוצות שהצטרף</th>
                        <th>זיכרונות</th>
                        <th>סטטוס</th>
                        <th>פעולות</th>
                    </tr>
                </thead>

                <tbody>
                    {regularUsers.map((user) => (
                        <tr key={user.id}>
                            <td>
                                <strong>{user.fullName}</strong>
                                <div>{user.email}</div>
                            </td>
                            <td>{user.boardsCreated}</td>
                            <td>{user.boardsJoined}</td>
                            <td>{user.memoriesCount}</td>
                            <td>{user.isBlocked ? "חסום" : "פעיל"}</td>
                            <td>
                                <button
                                    type="button" disabled={blockMutation.isPending }
                                    onClick={() => {
                                        setActionError("");
                                        blockMutation.mutate({ userId: user.id, isBlocked: !user.isBlocked });
                                    }} >
                                    {blockMutation.isPending && blockMutation.variables?.userId === user.id
                                        ? "מעדכן..." : user.isBlocked ? "ביטול חסימה" : "חסימה"}
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </section>
    );
};

export default AdminUsersTable;