import type { Group } from "../../types/group.types";
import GroupCard from "../GroupCard";

type Props = {
    groups: Group[];
};

const AdminGroupsSection = ({ groups }: Props) => {
    return (
        <section>
            <h2>ניהול קבוצות</h2>

            {groups.length === 0 ? (<p>אין קבוצות להצגה</p>
            ) : (
                <div className="groups-grid">
                    {groups.map((group) => (
                       <GroupCard  key={group.id} group={group} isAdmin={true} />
                    ))}
                </div>
            )}
        </section>
    );
};

export default AdminGroupsSection;