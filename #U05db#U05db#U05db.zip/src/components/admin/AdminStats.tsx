import type { AdminStatsResponse } from "../../types/admin.types";

const AdminStats = ({
    usersCount,
    groupsCount,
    memoriesCount
}: AdminStatsResponse) => {
    return (
        <section className="admin-stats">
            <div className="stat-card">
                <h3>משתמשים</h3>
                <strong>{usersCount}</strong>
            </div>

            <div className="stat-card">
                <h3>קבוצות</h3>
                <strong>{groupsCount}</strong>
            </div>

            <div className="stat-card">
                <h3>זיכרונות</h3>
                <strong>{memoriesCount}</strong>
            </div>
        </section>
    );
};

export default AdminStats;