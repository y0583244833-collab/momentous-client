import { useContext } from "react"
import { AuthContext } from "../context/AuthContext"


 export const LogOutButton=()=>{

    const auth=useContext(AuthContext);

    return(
        <button onClick={auth?.logout}>התנתקות</button>
    )
}