import { useState } from "react";
import { useNavigate } from "react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getMyInvitations, acceptInvitation, declineInvitation } from "../api/invitationsApi";
import InvitationCard from "./InvitationCard";
import "./InvitationsBell.css";

const InvitationsBell = () => {
    const [open, setOpen] = useState(false);
    const [error, setError] = useState("");
    const navigate = useNavigate();
    const queryClient = useQueryClient();

    const { data, isPending, isError } = useQuery({
        queryKey: ["invitations"],
        queryFn: () => getMyInvitations(1),
        refetchInterval: 30000
    });
    const refresh = () => {
        queryClient.invalidateQueries({ queryKey: ["invitations"] });
        queryClient.invalidateQueries({ queryKey: ["groups"] });
    };

    const accept = useMutation({ mutationFn: acceptInvitation, onSuccess: refresh });

    const decline = useMutation({
        mutationFn: declineInvitation, onSuccess: refresh
    });

    const handleAccept = (id: string) => {
        setError("");

        accept.mutate(id, {
            onSuccess: (group) => {
                setOpen(false);
                navigate(`/groups/${group.id}`);
            },
            onError: () => setError("אישור ההזמנה נכשל")
        });
    };

    const handleDecline = (id: string) => {
        setError("");

        decline.mutate(id, {
            onError: () => setError("דחיית ההזמנה נכשלה")
        });
    };

    const count = data?.total ?? 0;
    const busy = accept.isPending || decline.isPending;

    return (
        <div className="invitations-bell" dir="rtl">
            <button
                type="button"
                className="bell-button"
                aria-label={`הזמנות ממתינות: ${count}`}
                aria-expanded={open}
                onClick={() => setOpen(!open)}  >
                🔔
                {count > 0 && (<span className="bell-badge">   {count > 99 ? "99+" : count} </span>)}
            </button>

            {open && (
                <div className="invitations-dropdown">
                    <div className="invitations-dropdown-header">
                        <h3>ההזמנות שלי</h3>
                        <button type="button" onClick={() => setOpen(false)}  > ✕ </button>
                    </div>

                    <div className="invitations-dropdown-list">
                        {isPending ? (<p>טוען הזמנות...</p>)
                            : isError ? (<p>טעינת ההזמנות נכשלה</p>)
                                : !data?.items.length ? (<p>אין הזמנות חדשות</p>)
                                    : (data.items.map(invitation => (
                                        <InvitationCard
                                            key={invitation.id}
                                            invitation={invitation}
                                            onAccept={handleAccept}
                                            onDecline={handleDecline}
                                            disabled={busy}
                                        />
                                    ))
                                    )}
                    </div>

                    {error && <p role="alert">{error}</p>}
                    {data && data.totalPages > 1 && (<p>מוצגות {data.items.length} מתוך {data.total} הזמנות</p>)}
                </div>
            )}
        </div>
    );
};

export default InvitationsBell;
