import { useMutation, useQueryClient } from "@tanstack/react-query";
import type { Memory } from "../types/memory.types";
import { likeMemory, unlikeMemory } from "../api/memoriesApi";

interface MemoryCardProps {
    memory: Memory;
}

const MemoryCard = ({ memory }: MemoryCardProps) => {
    const queryClient = useQueryClient();
    const likeMutation = useMutation({
        mutationFn: () => {
            return memory.likedByMe ? unlikeMemory(memory.id) : likeMemory(memory.id);
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ["memories", memory.boardId] });
        }
    });

    return (
        <article className="memory-card" dir="rtl">

            <span>{memory.typeLabel}</span>
            <h3>{memory.title}</h3>
            <p>{memory.content}</p>
            {memory.imageUrl && (
                <img
                    src={memory.imageUrl}
                    alt={memory.title}
                    className="memory-card-image" />
            )}
            {memory.placeUrl && (
                <a
                    href={memory.placeUrl}
                    target="_blank"
                >צפייה במיקום</a>
            )}
            {memory.happenedAt && (<p><strong>תאריך הזיכרון: </strong>{new Date(memory.happenedAt).toLocaleDateString("he-IL")}</p>)}
            <div className="memory-card-footer">
                <div>
                    <p><strong>נוצר על ידי: </strong>{memory.author.fullName}</p>
                    <p> <strong>תאריך יצירה: </strong>{new Date(memory.createdAt).toLocaleDateString("he-IL")}</p>
                </div>

                <div className="memory-card-likes">
                    <button
                        type="button"
                        onClick={() => likeMutation.mutate()}
                        disabled={likeMutation.isPending}
                        aria-pressed={memory.likedByMe} >
                        {memory.likedByMe ? "❤️ אהבתי" : "♡ לייק"}
                    </button>
                    <span>{memory.likesCount} לייקים</span>
                </div>
            </div>

            {likeMutation.isError && (<p role="alert">לא הצלחנו לעדכן את הלייק. נסי שוב.</p>)}
        </article>
    );
};
export default MemoryCard;
