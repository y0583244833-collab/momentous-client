import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import api from "../api/api";
import "./GroupMembersHover.css";

interface Member {
    id: string;
    fullName: string;
    avatarUrl: string | null;
    isCreator: boolean;
    joinedAt: string;
}

const GroupMembersHover = ({ groupId }: { groupId: string }) => {
    const [open, setOpen] = useState(false);

    const { data: members, isPending, isError } = useQuery({
        queryKey: ["group-members", groupId],
        queryFn: async () => {
            const response = await api.get<Member[]>(
                `/api/boards/${groupId}/members`
            );
            return response.data;
        },
        enabled: open
    });

    return (
        <div
            className="members-hover"
            onMouseEnter={() => setOpen(true)}
            onMouseLeave={() => setOpen(false)}
        >
            <span className="members-trigger" tabIndex={0}
                onFocus={() => setOpen(true)}
                onBlur={(event) => {
                    if (!event.currentTarget.parentElement?.contains(event.relatedTarget as Node)) {
                        setOpen(false);
                    }
                }}>   👥 משתתפי הקבוצה
            </span>

            {open && (
                <div className="members-popover">
                    <h4>משתתפי הקבוצה</h4>
                    {isPending ? (<p>טוען משתתפים...</p>)
                        : isError ? (<p>לא ניתן לטעון משתתפים</p>)
                            : (
                                <div className="members-list">
                                    {members?.map(member => (
                                        <div className="member-row" key={member.id}>
                                            {member.avatarUrl ? (
                                                <img
                                                    src={member.avatarUrl}
                                                    alt=""
                                                    className="member-avatar"
                                                />
                                            ) : (
                                                <span className="member-avatar member-placeholder">
                                                    {member.fullName.charAt(0)}
                                                </span>
                                            )}
                                            <span>{member.fullName}</span>
                                            {member.isCreator && (<small>יוצר הקבוצה</small>)}
                                        </div>
                                    ))}
                                </div>
                            )}
                </div>
            )}
        </div>
    );
};

export default GroupMembersHover;
