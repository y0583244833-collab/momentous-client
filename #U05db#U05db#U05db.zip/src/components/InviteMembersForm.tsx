import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm, useFieldArray } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { inviteMembers } from "../api/invitationsApi";
import type { InviteMembersResponse } from "../types/invitation.types";
import { emailsSchema } from "../validation/schemas"
interface Props {
    groupId: string;
}

interface FormValues {
    participants: { email: string }[];
}

const InviteMembersForm = ({ groupId }: Props) => {
    const [result, setResult] = useState<InviteMembersResponse | null>(null);

    const {
        register,
        control,
        handleSubmit,
        reset,
        formState: { errors }
    } = useForm<FormValues>({
        resolver: yupResolver(emailsSchema),
        defaultValues: {
            participants: [{ email: "" }]
        }
    });

    const { fields, append, remove } = useFieldArray({
        control,
        name: "participants"
    });

    const mutation = useMutation({
        mutationFn: (emails: string[]) =>
            inviteMembers(groupId, { emails }),

        onSuccess: (data) => {
            setResult(data);
            reset();
        }
    });

    const onSubmit = (data: FormValues) => {
        setResult(null);

        const emails = data.participants.map(
            participant => participant.email.trim().toLowerCase()
        );

        mutation.mutate(emails);
    };

    return (
        <div dir="rtl">
            <h2>הזמנת משתתפים</h2>

            <form onSubmit={handleSubmit(onSubmit)}>
                {fields.map((field, index) => (
                    <div key={field.id}>
                        <label htmlFor={`email-${index}`}>
                            אימייל משתתף {index + 1}
                        </label>

                        <input
                            id={`email-${index}`}
                            type="email"
                            {...register(`participants.${index}.email`)}
                        />

                        {errors.participants?.[index]?.email && (
                            <p role="alert">
                                {errors.participants[index]?.email?.message}
                            </p>
                        )}

                        {fields.length > 1 && (
                            <button
                                type="button"
                                onClick={() => remove(index)}
                            >הסרה
                            </button>
                        )}
                    </div>
                ))}

                <button
                    type="button"
                    onClick={() => append({ email: "" })}
                > + הוספת משתתף</button>

                <button
                    type="submit"
                    disabled={mutation.isPending}
                >
                    {mutation.isPending ? "שולח הזמנות..." : "שליחת הזמנות"}
                </button>
            </form>

            {mutation.isError && (<p role="alert">שליחת ההזמנות נכשלה.</p>)}

            {result && (
                <div>
                    <p>נשלחו {result.invitedCount} הזמנות.</p>

                    {result.results.map(item => (
                        <p key={item.email}>{item.email}:{" "}
                            {item.result === "INVITED"
                                ? "הוזמן בהצלחה"
                                : item.result === "ALREADY_MEMBER"
                                    ? "כבר חבר בקבוצה"
                                    : `סטטוס: ${item.result}`}
                        </p>
                    ))}
                </div>
            )}
        </div>
    );

};

export default InviteMembersForm;
