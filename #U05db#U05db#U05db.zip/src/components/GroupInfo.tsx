
import type { Group } from "../types/group.types";

interface GroupInfoProps {
    group: Group;
}

const formatDate = (date: string) => {
    const parsed = new Date(date);

    if (Number.isNaN(parsed.getTime())) {
        return "תאריך לא זמין";
    }

    return parsed.toLocaleDateString("he-IL", { day: "numeric", month: "long", year: "numeric" });
};

const GroupInfo = ({ group }: GroupInfoProps) => {
    return (
        <>
            <section className="group-details-section">
                <h2>על הקבוצה</h2>
                <p className="group-details-description">
                    {group.description?.trim() ? group.description : "עדיין לא נוסף תיאור לקבוצה."}
                </p>
            </section>

            <section className="group-details-section">
                <h2>הקבוצה במספרים</h2>
                <div className="group-details-stats">
                    <article className="group-stat">
                        <span>👥</span>
                        <strong>{group.membersCount}</strong>
                        <span>משתתפים</span>
                    </article>

                    <article className="group-stat">
                        <span>📸</span>
                        <strong>{group.memoriesCount}</strong>
                        <span>זיכרונות</span>
                    </article>

                    <article className="group-stat">
                        <span>📅</span>
                        <strong>{formatDate(group.eventDate)}</strong>
                        <span>תאריך האירוע</span>
                    </article>
                </div>
            </section>

            <section className="group-details-section">
                <h2>מי יצר את הקבוצה?</h2>
                <div className="group-details-creator">
                    {group.creator.avatarUrl ? (
                        <img
                            src={group.creator.avatarUrl}
                            alt=""
                            className="group-creator-avatar" />)
                        : (
                            <div className="group-creator-avatar group-creator-fallback">
                                <span>👤</span>
                            </div>
                        )}

                    <div>
                        <strong>{group.creator.fullName}</strong>
                        {group.isCreator && (<p>את יצרת את הקבוצה הזאת</p>)}
                    </div>
                </div>
            </section>

            <section className="group-details-section">
                <h2>מידע נוסף</h2>
                <dl className="group-details-info">
                    <div>
                        <dt>סוג האירוע</dt>
                        <dd>{group.eventTypeLabel}</dd>
                    </div>
                    <div>
                        <dt>הקבוצה נוצרה בתאריך</dt>
                        <dd>{formatDate(group.createdAt)}</dd>
                    </div>
                    <div>
                        <dt>פעילות אחרונה</dt>
                        <dd>{formatDate(group.lastActivityAt)}</dd>
                    </div>
                    <div>
                        <dt>עדכון אחרון</dt>
                        <dd>{formatDate(group.updatedAt)}</dd>
                    </div>

                </dl>
            </section>
        </>
    );
};

export default GroupInfo;
