import { Link } from "react-router";

const Footer = () => {
    return (
        <footer className="footer">
            <span>© 2026 Momenta</span>
            <p>Momenta – הרגעים שלכם, הזיכרונות של כולם</p>
            <span>פותח ע״י ריקי ילין</span>
            <Link to="/">דף הבית</Link>
        </footer>
    );
};

export default Footer;