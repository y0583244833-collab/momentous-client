import { useQuery } from "@tanstack/react-query";
import { getMemories } from "../api/memoriesApi";
import MemoryCard from "./MemoryCard";

interface MemoriesSectionProps {
    groupId: string;
}
const MemoriesSection = ({ groupId }: MemoriesSectionProps) => {
    const {
        data,
        isPending,
        isError
    } = useQuery({
        queryKey: ["memories", groupId],
        queryFn: () => getMemories(groupId)
    });
    if (isPending) {
        return <p>טוענים זיכרונות...</p>;
    }
    if (isError) {
        return <p>לא הצלחנו לטעון את הזיכרונות.</p>;
    }

    return (
        <section className="group-details-section">
            <h2>הזיכרונות שלנו</h2>
            {data.items.length === 0 ? (
                <p>עדיין לא נוספו זיכרונות לקבוצה.</p>)
                : (
                    <div className="memories-list">
                        {data.items.map(memory => (
                            <MemoryCard key={memory.id} memory={memory} />
                        ))}
                    </div>
                )}
        </section>
    );
};

export default MemoriesSection;
