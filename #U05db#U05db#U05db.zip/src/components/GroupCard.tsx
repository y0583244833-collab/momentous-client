import type { Group } from "../types/group.types";
import { Link } from "react-router";
interface GroupCardProps {
  group: Group;
  isAdmin?: boolean;
}
const GroupCard = ({ group, isAdmin = false }: GroupCardProps) => {
  return (
    <article className="group-card">

      {group.coverImageUrl ? (
        <img
          src={group.coverImageUrl}
          alt={`תמונת הכיסוי של ${group.name}`}
          className="group-card-image"
        />
      ) : (<div className="group-card-no-image">אין תמונת כיסוי </div>)}
      <div className="group-card-content">
        <h2>{group.name}</h2>
        <span>{group.eventTypeLabel}</span>
        {group.description && (<p>{group.description}</p>)}
        <p> תאריך האירוע: {group.eventDate}</p>
        <p> משתתפים: {group.membersCount}</p>
        <p> זיכרונות: {group.memoriesCount}</p>
        <p>נוצרה על ידי: {group.creator.fullName} </p>
        <p> פעילות אחרונה:{" "} {new Date(group.lastActivityAt).toLocaleDateString("he-IL")} </p>
      </div>
      {!isAdmin && (<Link to={`/groups/${group.id}`} className="enter-group-button">כניסה לקבוצה</Link>)}
       </article>
  );
};

export default GroupCard;
