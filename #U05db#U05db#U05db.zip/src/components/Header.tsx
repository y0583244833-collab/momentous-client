import { useContext } from "react"
import { AuthContext } from "../context/AuthContext";
import { Link,NavLink } from "react-router";
import { LogOutButton } from "./logoutButton";
import InvitationsBell from "./InvitationsBell";

const Header=()=>{
    const auth=useContext(AuthContext);
   return(
<header>
    <nav>
        <Link to="/">momenta</Link>
        {auth?.isAuthenticated?(
            <>
              <span>שלום,{auth.user?.fullName}</span>
              {auth?.user?.role === "USER" && (<Link to="/groups">הלוחות שלי</Link>
)}
              {auth.user?.role==="ADMIN"&&
              <NavLink to="/admin">ניהול מערכת</NavLink>}
              <LogOutButton
              />
              {auth.user?.role !== "ADMIN" && <InvitationsBell />}
            </>
  ):
  (
    <>
    <NavLink to="/login">להתחברות</NavLink>
    <NavLink to="/signup">להרשמה</NavLink>
    </>


  )}
    </nav>
</header>


   )
}
export default Header;